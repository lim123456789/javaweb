package kr.co.zerock.b01.config;


import io.swagger.v3.oas.annotations.Operation;
import org.springdoc.core.models.GroupedOpenApi;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
//import springfox.documentation.builders.ApiInfoBuilder;
//import springfox.documentation.builders.PathSelectors;
//import springfox.documentation.builders.RequestHandlerSelectors;
//import springfox.documentation.service.ApiInfo;
//import springfox.documentation.spi.DocumentationType;
//import springfox.documentation.spring.web.plugins.Docket;

@Configuration
public class SwaggerConfig {

    @Bean
    public GroupedOpenApi adminApi() {
        return GroupedOpenApi.builder()
                .group("springshop-admin")
                .packagesToScan("kr.co.zerock.b01.controller")
                .build();
    }

    @Operation(summary = "rest")
    @Bean
    public GroupedOpenApi restAPI() {
        return GroupedOpenApi.builder()
                .group("REST API")
                .pathsToMatch("/**")
                .pathsToExclude("/board/**")
                .build();
    }

    @Operation(summary = "common")
    @Bean
    public GroupedOpenApi commonAPI() {
        return GroupedOpenApi.builder()
                .group("common API")
                .pathsToMatch("/board/**")
                .build();
    }
}
