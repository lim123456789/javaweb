package kr.co.zerock.api01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Api01Application {

	public static void main(String[] args) {
		SpringApplication.run(Api01Application.class, args);
	}

}
