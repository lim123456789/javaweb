package kr.co.zerock.api01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Api01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
